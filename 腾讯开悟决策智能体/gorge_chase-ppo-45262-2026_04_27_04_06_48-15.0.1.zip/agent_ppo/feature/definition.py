#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Data definitions, GAE computation for Gorge Chase PPO.
峡谷追猎 PPO 数据类定义与 GAE 计算。

修复：
  1. sample_process 统一接受 last_value 参数（必填），与 workflow 对齐。
  2. GAE 中 non_terminal 使用 done（terminated），而非 truncated，
     truncated 时末帧通过 last_value != 0 自然 bootstrap，不截断回报。
"""

import numpy as np
from common_python.utils.common_func import create_cls, attached
from agent_ppo.conf.conf import Config


# ObsData
ObsData = create_cls("ObsData", feature=None, legal_action=None)

# ActData
ActData = create_cls("ActData", action=None, d_action=None, prob=None, value=None)

# SampleData
SampleData = create_cls(
    "SampleData",
    obs=Config.DIM_OF_OBSERVATION,
    legal_action=Config.ACTION_NUM,
    act=1,
    reward=Config.VALUE_NUM,
    reward_sum=Config.VALUE_NUM,
    done=1,           # terminated（真正死亡）
    truncated=1,      # truncated（时间截断）
    value=Config.VALUE_NUM,
    next_value=Config.VALUE_NUM,
    advantage=Config.VALUE_NUM,
    prob=Config.ACTION_NUM,
)


def sample_process(list_sample_data, last_value):
    """
    填充 next_value 并计算 GAE。

    last_value:
      - truncated → Critic 对末帧的 V(s') 估计（非零）
      - terminated → 0.0（terminal state，价值为零）
    """
    # 填 next_value
    for i in range(len(list_sample_data) - 1):
        list_sample_data[i].next_value = list_sample_data[i + 1].value

    # 最后一帧
    list_sample_data[-1].next_value = last_value

    _calc_gae(list_sample_data)
    return list_sample_data


def _calc_gae(list_sample_data):
    """Compute GAE (Generalized Advantage Estimation).

    关键：non_terminal 仅由 done（=terminated）决定。
    truncated 时 last_value != 0，bootstrap 自然发生，不需要额外截断。
    """
    gae = 0.0
    gamma = Config.GAMMA
    lamda = Config.LAMDA
    for sample in reversed(list_sample_data):
        # 只有真正 terminated 才截断回报流
        non_terminal = 1.0 - float(sample.done)

        delta = float(sample.reward) + gamma * float(sample.next_value) * non_terminal - float(sample.value)
        gae = delta + gamma * lamda * non_terminal * gae
        sample.advantage = np.array([gae], dtype=np.float32)
        sample.reward_sum = np.array([gae + float(sample.value)], dtype=np.float32)