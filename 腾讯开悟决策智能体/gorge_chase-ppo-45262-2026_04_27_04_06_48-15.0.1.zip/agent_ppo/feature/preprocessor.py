#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Feature preprocessor and reward design for Gorge Chase PPO.
峡谷追猎 PPO 特征预处理与奖励设计。
"""

import numpy as np
from collections import deque

# Map size / 地图尺寸（128×128）
MAP_SIZE = 128.0
# Max monster speed / 最大怪物速度
MAX_MONSTER_SPEED = 2.0
# Max distance bucket / 距离桶最大值
MAX_DIST_BUCKET = 5.0
# Max flash cooldown / 最大闪现冷却步数
MAX_FLASH_CD = 200.0
# Max buff duration / buff最大持续时间
MAX_BUFF_DURATION = 50.0

# Reward shaping / 奖励塑形超参（先给一套可训的默认值，后续可再调）
BUFF_EVENT_REWARD = 1.5
BUFF_APPROACH_REWARD = 0.04
# Treasure shaping / 宝箱相关奖励（事件+接近）
TREASURE_EVENT_REWARD = 3.0

# [MODIFIED] 宝箱接近奖励分为视野内和视野外两部分
TREASURE_APPROACH_VISIBLE_MAX = 0.1   # 视野内：最大接近奖励
TREASURE_APPROACH_BUCKET_BONUS = 0.02  # 视野外：宝箱密集方向的微弱奖励
# Safe gate: only reward approaching resources when monsters are not too close
SAFE_MIN_DIST_NORM = 0.05

# Flash value reward / 闪现价值奖励（只奖励“救命闪现”，避免 CD 好就乱闪）
FLASH_POS_REWARD = 1.0
FLASH_NEG_REWARD = -0.2
FLASH_DANGER_GATE_NORM = 0.10
FLASH_DIST_INCREASE_NORM = 0.06

# Phase weighting / 阶段平滑权重（资源→生存的平滑切换）
PHASE_MONSTER_WEIGHT_SCALE = 0.5
PHASE_RESOURCE_WEIGHT_SCALE = 0.5

# Anti-stuck / 防磨蹭（10步位移过小惩罚）
STUCK_WINDOW = 10
STUCK_DIST_THRESHOLD = 5.0
STUCK_PENALTY = -0.2
MAX_MOVE_DIST = 180.0

# [A+B NEW] 宝箱记忆参数
MAX_TREASURE_MEMORY = 10          # 缓存最多10个宝箱
MAX_TREASURE_BUCKET_FEAT = 5      # 桶距离/方位取前5个


def _norm(v, v_max, v_min=0.0):
    """Normalize value to [0, 1].

    将值归一化到 [0, 1]。
    """
    v = float(np.clip(v, v_min, v_max))
    return (v - v_min) / (v_max - v_min) if (v_max - v_min) > 1e-6 else 0.0

def _dir_to_sincos(dir_id):
    """Convert direction id (1~8) to sin/cos tuple."""
    try:
        d = int(dir_id)
    except Exception:
        d = 0
    if 1 <= d <= 8:
        angle = (d - 1) * (np.pi / 4)
        return np.sin(angle), np.cos(angle)
    return 0.0, 0.0

class Preprocessor:
    def __init__(self):
        self.reset()

    def reset(self):
        self.step_no = 0
        self.max_step = 1000
        self.last_min_monster_dist_norm = 0.5
        self.last_collected_buff = 0
        self.last_nearest_buff_bucket = None
        self.last_treasure_score = 0.0
        self.last_nearest_treasure_bucket = None
        self._pos_hist = deque(maxlen=STUCK_WINDOW + 1)
        self.last_monster_pos = [None, None]  # 初始化怪物历史位置
        self.second_monster_timer = None
        self.predicted_spawn_pos = None
        self.seen_treasure_positions = set() #tre初次看到
        self.last_tre_bucket_norm = 1.0
        self.last_bucket_score = 0.0
                # 每局统计
        self.danger_steps = 0      # 处于危险状态的步数
        self.stuck_steps = 0       # 处于卡住状态的步数
        self.flash_use_count = 0   # 闪现使用次数
        self.flash_success_count = 0  # 闪现成功次数

        # [A+B NEW] 全局宝箱精确坐标记忆 + buff坐标缓存
        self.treasure_memory = {}   # {(x, z): True} 吃到后删除
        self.buff_memory = {}       # {(x, z): True} 每帧刷新（buff会重生）


    @staticmethod
    def _dir_onehot_8(dir_id):
        """Convert env direction id (1~8) to 8D one-hot."""
        v = np.zeros(8, dtype=np.float32)
        try:
            d = int(dir_id)
        except Exception:
            d = 0
        if 1 <= d <= 8:
            v[d - 1] = 1.0
        return v
    
    def _update_memory_from_organs(self, organs):
        #[A+B NEW] 从organs更新全局记忆。
        #- 宝箱：视野内有效坐标 -> treasure_memory
        #- buff：视野内有效坐标 -> buff_memory（每帧重建） 
        current_buff = {}
        for o in organs:
            sub = int(o.get("sub_type", 0))
            status = int(o.get("status", 0))
            if status != 1:
                continue
            pos = o.get("pos", {})
            px, pz = pos.get("x", 0), pos.get("z", 0)
            if px == 0 and pz == 0:
                continue
            if sub == 1:   # 宝箱
                self.treasure_memory[(px, pz)] = True
            elif sub == 2: # buff
                current_buff[(px, pz)] = True
        self.buff_memory = current_buff

    def feature_process(self, env_obs, last_action):
        """Process env_obs into feature vector, legal_action mask, and reward.

        将 env_obs 转换为特征向量、合法动作掩码和即时奖励。
        """
        observation = env_obs["observation"]
        frame_state = observation["frame_state"]
        env_info = observation["env_info"]
        map_info = observation["map_info"]
        # NOTE: Different env versions may use `legal_action` or `legal_act`
        legal_act_raw = observation.get("legal_action", observation.get("legal_act", None))

        self.step_no = observation["step_no"]
        self.max_step = env_info.get("max_step", 2000)
        # NOTE: Official env_info exposes `monster_speed` as the configured monster speed-related value.
        # In Gorge Chase, this field is used as the monster speedup time config on most env builds.
        # Fallback to 500 (official default monster_speedup) if missing.
        speedup_step = float(env_info.get("monster_speed", 500))

        # Hero self features (4D) / 英雄自身特征

        # 在 hero_feat 之前
        hero = frame_state["heroes"]
        hero_pos = hero["pos"]
        hx = float(hero_pos["x"])   # ← 加这行
        hz = float(hero_pos["z"])   # ← 加这行
        # 第二怪物出生预警
        if self.second_monster_timer is None:
            self.second_monster_timer = int(env_info.get("monster_interval", 200))
        self.second_monster_timer = max(0, self.second_monster_timer - 1)

        if self.second_monster_timer == 10:
            self.predicted_spawn_pos = (hero_pos["x"], hero_pos["z"])

        if self.predicted_spawn_pos is not None and self.second_monster_timer > 0:
            spawn_dist = np.sqrt(
                (hero_pos["x"] - self.predicted_spawn_pos[0])**2 +
                (hero_pos["z"] - self.predicted_spawn_pos[1])**2
            )
            spawn_danger = 1.0 - _norm(spawn_dist, 10)
        else:
            spawn_danger = 0.0

        if self.second_monster_timer == 0:
            self.predicted_spawn_pos = None
    
        hero_x_norm = _norm(hero_pos["x"], MAP_SIZE)
        hero_z_norm = _norm(hero_pos["z"], MAP_SIZE)
        flash_cd_norm = _norm(hero["flash_cooldown"], MAX_FLASH_CD)
        buff_remain_norm = _norm(hero["buff_remaining_time"], MAX_BUFF_DURATION)

       
         # Anti-stuck feature / 防磨蹭特征：10步位移 + 10步前位置
        self._pos_hist.append((float(hero_pos["x"]), float(hero_pos["z"])))
        move_dist_10 = 0.0
        prev_pos_x_norm = hero_x_norm
        prev_pos_z_norm = hero_z_norm
        if len(self._pos_hist) >= STUCK_WINDOW + 1:
            x0, z0 = self._pos_hist[0]
            x1, z1 = self._pos_hist[-1]
            move_dist_10 = float(np.sqrt((x1 - x0) ** 2 + (z1 - z0) ** 2))
            prev_pos_x_norm = _norm(x0, MAP_SIZE)
            prev_pos_z_norm = _norm(z0, MAP_SIZE)
        move_dist_10_norm = _norm(move_dist_10, MAX_MOVE_DIST)
        anti_stuck_feat = np.array([
            move_dist_10_norm,    # 0: 10步总路径长度
            prev_pos_x_norm,      # 1: 10步前位置X
            prev_pos_z_norm,      # 2: 10步前位置Z
        ], dtype=np.float32)

        # Monster features (13D x 2) / 怪物特征
        monsters = frame_state.get("monsters", [])
        monster_feats = []
        for i in range(2):
            if i < len(monsters):
                m = monsters[i]
                m_pos = m["pos"]
                # 判断是否在视野内：视野内有有效坐标，视野外坐标为(0,0)
                is_in_view = float(m_pos["x"] > 0 or m_pos["z"] > 0)
                
                # === 以下字段视野内外都有（官方始终提供） ===
                # 官方距离桶 (1维)
                hero_l2_bucket = m.get("hero_l2_distance", 5)  # 0-5
                bucket_norm = _norm(hero_l2_bucket, 5)
                
                # 官方相对方位 sin/cos编码 (2维)
                relative_dir = m.get("hero_relative_direction", 0)  # 0-8
                if relative_dir > 0:
                    angle = (relative_dir - 1) * (np.pi / 4)
                    dir_sin = np.sin(angle)
                    dir_cos = np.cos(angle)
                else:
                    dir_sin = 0.0
                    dir_cos = 0.0
                
                # 怪物速度（视野外可能也有，保守处理）
                m_speed_norm = _norm(m.get("speed", 1), MAX_MONSTER_SPEED)
                
                # 怪物出现间隔（环境配置，始终可用）
                #monster_interval = m.get("monster_interval", 200)
                #interval_norm = _norm(monster_interval, 2000)
                # 改为
                interval_norm = 1.0  # 固定值200
                
                # === 以下字段仅在视野内有效 ===
                if is_in_view:
                    m_x_norm = _norm(m_pos["x"], MAP_SIZE)
                    m_z_norm = _norm(m_pos["z"], MAP_SIZE)

                    # 精确欧式距离
                    raw_dist = np.sqrt((hero_pos["x"] - m_pos["x"]) ** 2 + (hero_pos["z"] - m_pos["z"]) ** 2)
                    dist_norm = _norm(raw_dist, MAP_SIZE * 1.41)
                    
                    # 出生点信息
                    start_pos = m.get("start_pos", {"x": 0, "z": 0})
                    start_x_norm = _norm(start_pos["x"], MAP_SIZE)
                    start_z_norm = _norm(start_pos["z"], MAP_SIZE)
                    
                    # 怪物已移动距离
                    start_dist = np.sqrt((m_pos["x"] - start_pos["x"]) ** 2 + (m_pos["z"] - start_pos["z"]) ** 2)
                    start_dist_norm = _norm(start_dist, MAP_SIZE * 1.41)
                    
                    # 是否在靠近
                    if self.last_monster_pos[i] is not None:
                        prev_x, prev_z = self.last_monster_pos[i]
                        prev_dist = np.sqrt((hero_pos["x"] - prev_x) ** 2 + (hero_pos["z"] - prev_z) ** 2)
                        is_approaching = 1.0 if raw_dist < prev_dist else 0.0
                    else:
                        is_approaching = 0.0
                    
                    # 更新历史位置
                    self.last_monster_pos[i] = (m_pos["x"], m_pos["z"])
                else:
                    # [FIX] 视野外用桶距离估算，避免跳变到1.0
                    m_x_norm = 0.0
                    m_z_norm = 0.0
                    # 每个桶跨度30格，取中值估算：桶0→15格, 桶1→45格, ..., 桶5→165格
                    estimated_dist = hero_l2_bucket * 30.0 + 15.0
                    dist_norm = _norm(estimated_dist, MAP_SIZE * 1.41)
                    start_x_norm = 0.0
                    start_z_norm = 0.0
                    start_dist_norm = 0.0
                    is_approaching = 0.0
                    self.last_monster_pos[i] = None

                #怪物特征总结
                monster_feats.append(np.array([
                is_in_view,        # 0: 视野标志 (门控信号)
                m_x_norm,          # 1: 怪物X坐标(视野外=0)
                m_z_norm,          # 2: 怪物Z坐标(视野外=0)
                m_speed_norm,      # 3: 怪物速度（始终可用）
                dist_norm,         # 4: 精确欧式距离(视野外=1)
                bucket_norm,       # 5: 官方距离桶（始终可用）
                dir_sin,           # 6: 相对方位sin（始终可用）
                dir_cos,           # 7: 相对方位cos（始终可用）
                is_approaching,    # 8: 是否正在靠近(视野外=0)
                start_x_norm,      # 9: 出生点X(视野外=0)
                start_z_norm,      # 10: 出生点Z(视野外=0)
                start_dist_norm,   # 11: 已移动距离(视野外=0)
                interval_norm,     # 12: 怪物出现间隔（始终可用）
            ], dtype=np.float32))
            else:
                monster_feats.append(np.zeros(13, dtype=np.float32))#13维怪物特征拼接

         # [FIX] 当前最近怪物距离（视野内用精确值，视野外用桶估算）
        cur_min_dist_norm = 1.0
        for i, m_feat in enumerate(monster_feats):
            if i >= len(monsters):
                continue
            if m_feat[0] > 0:
                # 视野内：用精确距离
                cur_min_dist_norm = min(cur_min_dist_norm, m_feat[4])
            else:
                # 视野外：用桶估算距离，直接取最小值
                cur_min_dist_norm = min(cur_min_dist_norm, m_feat[4])

        # 死胡同检测
        center = 10
        passable_count = 0

        # 计算可通行方向的最长连续通路（最深）
        max_depth = 0
        # 计算连通的可通行区域大小（最广）
        max_open_area = 0

        for dx, dz in [(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)]:
            nx, nz = center + dx, center + dz
            if 0 <= nx < 21 and 0 <= nz < 21:
                if map_info[nz][nx] == 1:
                    passable_count += 1
                    # 沿这个方向走，计算通路长度
                    depth = 1
                    cx, cz = center + dx * 2, center + dz * 2
                    while 0 <= cx < 21 and 0 <= cz < 21 and map_info[cz][cx] == 1:
                        depth += 1
                        cx += dx
                        cz += dz
                    max_depth = max(max_depth, depth)

        # 连通区域大小：从英雄位置 BFS
        from collections import deque
        visited = [[False]*21 for _ in range(21)]
        q = deque([(center, center)])
        visited[center][center] = True
        area = 1
        while q:
            x, z = q.popleft()
            for dx, dz in [(1,0),(-1,0),(0,1),(0,-1)]:
                nx, nz = x + dx, z + dz
                if 0 <= nx < 21 and 0 <= nz < 21 and not visited[nz][nx] and map_info[nz][nx] == 1:
                    visited[nz][nx] = True
                    area += 1
                    q.append((nx, nz))
        max_open_area = area

        trapped_norm = _norm(8 - passable_count, 8)
        depth_norm = _norm(max_depth, 10)        # 最长通路10格（半视野）
        open_norm = _norm(max_open_area, 441)    # 连通区域/最大441

        hero_feat = np.array([hero_x_norm, hero_z_norm, flash_cd_norm, buff_remain_norm, cur_min_dist_norm, trapped_norm, depth_norm, open_norm, spawn_danger], dtype=np.float32)



        # Local map (21x21) / 局部地图（21×21，1=可通行，0=障碍物）
        # We flatten it and let the model apply a lightweight CNN.
        map_flat = np.zeros(21 * 21, dtype=np.float32)
        if map_info is not None and len(map_info) >= 21 and len(map_info[0]) >= 21:
            m = np.array(map_info, dtype=np.float32)
            # Ensure 0/1 semantics: 1=passable, 0=blocked
            m = (m != 0).astype(np.float32)
            map_flat = m[:21, :21].reshape(-1)

         # ========================
        # [A+B NEW] 宝物特征区
        # ========================
        organs = frame_state.get("organs", []) or []
        self._update_memory_from_organs(organs)

        # ----- 方案B：前5宝箱桶距离+方位 (20D) -----
        all_tre_bucket = []
        for o in organs:
            if int(o.get("sub_type", 0)) != 1 or int(o.get("status", 0)) != 1:
                continue
            b = int(o.get("hero_l2_distance", 5))
            d = int(o.get("hero_relative_direction", 0))
            pos = o.get("pos", {})
            is_vis = 1.0 if (pos.get("x", 0) > 0 or pos.get("z", 0) > 0) else 0.0
            all_tre_bucket.append((b, d, is_vis))
        all_tre_bucket.sort(key=lambda x: x[0])

        bucket_tre_feat = np.zeros(MAX_TREASURE_BUCKET_FEAT * 4, dtype=np.float32)
        for idx, (b, d, is_vis) in enumerate(all_tre_bucket[:MAX_TREASURE_BUCKET_FEAT]):
            b_norm = _norm(b, MAX_DIST_BUCKET)
            sin_v, cos_v = _dir_to_sincos(d) if 1 <= d <= 8 else (0.0, 0.0)
            bucket_tre_feat[idx*4]   = b_norm
            bucket_tre_feat[idx*4+1] = sin_v
            bucket_tre_feat[idx*4+2] = cos_v
            bucket_tre_feat[idx*4+3] = is_vis

        # ----- 方案A：全局精确坐标记忆 (20D) -----
        def manhattan_dist(key):
            return abs(key[0] - hx) + abs(key[1] - hz)
        sorted_memory = sorted(self.treasure_memory.keys(), key=manhattan_dist)
        memory_tre_feat = np.zeros(MAX_TREASURE_MEMORY * 2, dtype=np.float32)
        for idx, (tx, tz) in enumerate(sorted_memory[:MAX_TREASURE_MEMORY]):
            memory_tre_feat[idx*2]   = _norm(tx, MAP_SIZE)
            memory_tre_feat[idx*2+1] = _norm(tz, MAP_SIZE)

        # 最近可见宝箱（用于奖励计算）
        has_visible_tre = 0.0
        nearest_tre_bucket = None
        nearest_tre_dir = 0
        first_sight_bonus = 0.0
        for o in organs:
            if int(o.get("sub_type", 0)) != 1 or int(o.get("status", 0)) != 1:
                continue
            pos = o.get("pos", {})
            px, pz = pos.get("x", 0), pos.get("z", 0)
            if px == 0 and pz == 0:
                continue
            has_visible_tre = 1.0
            tre_pos_key = (px, pz)
            if tre_pos_key not in self.seen_treasure_positions:
                first_sight_bonus = 0.2
                self.seen_treasure_positions.add(tre_pos_key)
            b = int(o.get("hero_l2_distance", 5))
            if nearest_tre_bucket is None or b < nearest_tre_bucket:
                nearest_tre_bucket = b
                nearest_tre_dir = int(o.get("hero_relative_direction", 0))

        if nearest_tre_bucket is None:
            tre_dist_bucket_norm = 1.0
            tre_dir_sin, tre_dir_cos = 0.0, 0.0
        else:
            tre_dist_bucket_norm = _norm(nearest_tre_bucket, MAX_DIST_BUCKET)
            tre_dir_sin, tre_dir_cos = _dir_to_sincos(nearest_tre_dir)
        ##结束

        # Nearest buff features (4D) / 最近加速 buff 特征
        # [dist_bucket_norm, dir_sin, dir_cos, is_visible]
        organs = frame_state.get("organs", []) or []
        nearest_buff_bucket = None
        nearest_buff_dir = 0
        has_visible_buff = 0.0
        for o in organs:
            if int(o.get("sub_type", 0)) != 2:
                continue
            if int(o.get("status", 0)) != 1:
                continue
            has_visible_buff = 1.0
            b = int(o.get("hero_l2_distance", MAX_DIST_BUCKET))
            if nearest_buff_bucket is None or b < nearest_buff_bucket:
                nearest_buff_bucket = b
                nearest_buff_dir = int(o.get("hero_relative_direction", 0))

        if nearest_buff_bucket is None:
            buff_dist_bucket_norm = 1.0
            buff_dir_sin = 0.0
            buff_dir_cos = 0.0
        else:
            buff_dist_bucket_norm = _norm(nearest_buff_bucket, MAX_DIST_BUCKET)
            if 1 <= nearest_buff_dir <= 8:
                angle = (nearest_buff_dir - 1) * (np.pi / 4)
                buff_dir_sin = np.sin(angle)
                buff_dir_cos = np.cos(angle)
            else:
                buff_dir_sin = 0.0
                buff_dir_cos = 0.0

        buff_feat = np.array(
            [buff_dist_bucket_norm, buff_dir_sin, buff_dir_cos, has_visible_buff], dtype=np.float32
        )

        

        # ----- 合并宝箱特征：可见4D + 桶距20D + 记忆20D = 44D -----
        vis_tre_feat = np.array([tre_dist_bucket_norm, tre_dir_sin, tre_dir_cos, has_visible_tre], dtype=np.float32)
        tre_feat = np.concatenate([vis_tre_feat, bucket_tre_feat, memory_tre_feat])

        # Legal action mask (16D) / 合法动作掩码（16维）
        legal_action = [1] * 16
        if isinstance(legal_act_raw, list) and legal_act_raw:
            if isinstance(legal_act_raw[0], bool):
                for j in range(min(16, len(legal_act_raw))):
                    legal_action[j] = int(bool(legal_act_raw[j]))
            else:
                valid_set = {int(a) for a in legal_act_raw if 0 <= int(a) < 16}
                legal_action = [1 if j in valid_set else 0 for j in range(16)]

        if sum(legal_action) == 0:
            legal_action = [1] * 16

      
        # Progress features (2D) / 进度特征
        step_norm = _norm(self.step_no, self.max_step)
        # phase_post: anchored at speedup_step, stable across curriculum changes
        denom = max(1.0, float(self.max_step) - speedup_step)
        phase_post = float(np.clip((float(self.step_no) - speedup_step) / denom, 0.0, 1.0))
        progress_feat = np.array([step_norm, phase_post], dtype=np.float32)

        # ========================
        # 特征拼接
        # ========================
        feature = np.concatenate([
            hero_feat,              # 9
            monster_feats[0],       # 13
            monster_feats[1],       # 13
            buff_feat,              # 4
            tre_feat,               # [A+B NEW] 44
            anti_stuck_feat,        # 3
            map_flat,               # 441
            np.array(legal_action, dtype=np.float32),  # 16
            progress_feat,          # 2
        ])

        # ========================
        # 奖励计算
        # ========================

         # ===== 距离塑形（仅危险时生效）=====
        prev_min_dist_norm = float(self.last_min_monster_dist_norm)
        dist_increase = cur_min_dist_norm - prev_min_dist_norm
        if cur_min_dist_norm < 0.06 or prev_min_dist_norm < 0.06:
            dist_shaping = 0.05 * dist_increase
        else:
            dist_shaping = 0.0

        # ===== 阶段衰减（保留你结构，但弱化影响）=====
        decay_weight = 1.0
        if self.step_no > 200:
            if self.step_no < 350:
                decay_weight = 1.0 - 0.2 * (self.step_no - 300) / 200.0  # ↓ 0.3→0.2
            else:
                decay_weight = 0.9  # ↑ 从0.8调高（避免后期不拿宝箱）

         # 宝箱事件
        treasure_score = float(env_info.get("treasure_score", 0.0))
        collected_this_step = treasure_score > self.last_treasure_score + 1e-6
        tre_event = 4.5 if collected_this_step else 0.0
        # [NEW] 宝箱价值随收集数递增：第1个×1.0, 第5个×1.4, 第10个×1.8
        treasures_collected = int(env_info.get("treasures_collected", 0))
        treasure_multiplier = 1.0 + 0.04 * treasures_collected  # 每个+10%

        tre_event *= decay_weight * treasure_multiplier


        # [A+B NEW] 吃宝箱后清理记忆
        if collected_this_step and self.treasure_memory:
            nearest_key = min(self.treasure_memory.keys(), key=manhattan_dist)
            del self.treasure_memory[nearest_key]

        self.last_treasure_score = treasure_score

        # ================================================================
        # [MODIFIED] 宝箱接近奖励（视野内 + 视野外，温和引导不超0.1/步）
        # ================================================================
        treasure_approach = 0.0

        # --- 视野内：靠近最近可见宝箱 ---
        # 条件：有可见宝箱 且 怪物不贴脸(距离>0.05≈约10格)
        #if has_visible_tre and nearest_tre_bucket is not None and cur_min_dist_norm > 0.017:
            # (1 - tre_dist_bucket_norm) 越接近宝箱值越大
            # 乘以0.08上限，确保每步最多+0.08
        #    treasure_approach += TREASURE_APPROACH_VISIBLE_MAX * (1.2 - tre_dist_bucket_norm)
        if has_visible_tre and nearest_tre_bucket is not None and cur_min_dist_norm > 0.028:
            cur_dist = tre_dist_bucket_norm
            prev_dist = self.last_tre_bucket_norm

            dist_delta = prev_dist - cur_dist   # 变近才为正

            # 1️⃣ 连续靠近奖励（小）
            treasure_approach += np.clip(dist_delta * 0.4, -0.02, 0.06)

            # 2️⃣ 绝对距离吸引（核心）
            base_reward = 0.08 * (1.0 - cur_dist)

            # 3️⃣ 危险缩放（关键）
            danger_scale = np.clip((cur_min_dist_norm - 0.02) / 0.04, 0.2, 1.0)

            treasure_approach += base_reward * danger_scale
                        
        #视野外
        #bucket_score = 0.0  # ✅ 先定义，防炸
        bucket_score = self.last_bucket_score  # 默认继承上一帧（关键！）
        updated_bucket = False
        if len(all_tre_bucket) > 0:
            has_near_visible = has_visible_tre and nearest_tre_bucket is not None and nearest_tre_bucket < 3

            if not has_near_visible:
                # ===== 方向统计 =====
                direction_counts = [0] * 8
                for b, d, _ in all_tre_bucket:
                    if 1 <= d <= 8:
                        direction_counts[d - 1] += 1

                max_count = max(direction_counts) if max(direction_counts) > 0 else 1

                # ===== 当前密度得分（0~1）=====
                bucket_score = max_count / 5.0
                updated_bucket = True

                # ===== ① 静态方向引导（弱化版 bonus）=====
                static_bonus = 0.02 * bucket_score   # ↓ 原来0.02 → 0.01

                # ===== ② 动态进步奖励（核心新增）=====
                
                delta_score = np.clip(bucket_score - self.last_bucket_score, -0.2, 0.2)
                dynamic_bonus = np.clip(delta_score * 0.08, -0.02, 0.04)

                # ✅ 加在这里（防送死关键！）
                if cur_min_dist_norm > 0.028:
                    treasure_approach += static_bonus + dynamic_bonus

        # ================================================================

        # ===== Buff事件（微调）=====
        collected_buff = int(env_info.get("collected_buff", 0))
        buff_event = 1.6 if collected_buff > self.last_collected_buff else 0.0  # ↓ 1.5→1.2
        buff_event *= decay_weight
        self.last_collected_buff = collected_buff

        # ===== 危险惩罚（分阶段）=====
        if self.step_no < 300:
            # 前期/中期（<300步）：危险惩罚较轻
            if cur_min_dist_norm < 0.028:
                danger_penalty = -0.07
            elif cur_min_dist_norm < 0.06:
                danger_penalty = -0.07 * (1.0 - (cur_min_dist_norm - 0.028) / 0.032)
            else:
                danger_penalty = 0.0
        else:
            # 后期（>=300步）：怪物已加速，危险惩罚加重
            if cur_min_dist_norm < 0.028:
                danger_penalty = -0.09
            elif cur_min_dist_norm < 0.06:
                danger_penalty = -0.09 * (1.0 - (cur_min_dist_norm - 0.028) / 0.032)
            else:
                danger_penalty = 0.0
        

        # ===== 闪现（基于危险距离+实际位移的精准评估）=====
        if isinstance(last_action, (int, np.integer)) and 8 <= int(last_action) <= 15:
            # 计算闪现实际位移（当前位置 vs 上一步位置）
            if len(self._pos_hist) >= 2:
                px, pz = self._pos_hist[-2]
                cx, cz = self._pos_hist[-1]
                flash_dist = float(np.sqrt((cx - px) ** 2 + (cz - pz) ** 2))
            else:
                flash_dist = 0.0

            # 闪现前怪物最近距离（用上一步的）
            prev_dist_norm = float(self.last_min_monster_dist_norm)
            prev_dist_grids = prev_dist_norm * MAP_SIZE * 1.41  # 反归一化到格数

            # 情况1：闪现前怪物在6格以内（危险）
            if prev_dist_grids < 6.0:
                if flash_dist >= 3.0:
                    # 有效闪现：按实际拉开距离计分
                    # dist_increase 是归一化值，转换为格数
                    dist_pulled = dist_increase * MAP_SIZE * 1.41
                    # 限制在3~10格范围计分，每格0.3分，最高3分
                    dist_pulled = float(np.clip(dist_pulled, 0.0, 10.0))
                    flash_value = min(dist_pulled * 0.3, 3.0)
                else:
                    # 闪现位移<3格：没闪出去，扣分
                    flash_value = -0.6
            # 情况2：闪现前怪物在6~10格（中等距离）
            elif prev_dist_grids < 10.0:
                flash_value = 0.0  # 不奖不扣
            # 情况3：闪现前怪物在10格以外（安全距离乱闪）
            else:
                flash_value = -1.0
        else:
            flash_value = 0.0

        # ===== 生存奖励（稳定主信号）=====
        #survive_reward = 0.1 + 0.3 * step_norm   # ↓ 从0.08+0.1改小
        # ===== 生存奖励（分阶段阶梯式） =====
        if self.step_no <= 200:
            # 前期：正常存活奖励，鼓励探索
            survive_reward = 0.07 + 0.12 * step_norm
        elif self.step_no <= 300:
            # 中期（200-300步）：降低基础存活，让宝箱成为主要激励
            survive_reward = 0.1 + 0.15 * step_norm
        else:
            # 后期（>300步）：怪物加速+第二怪物已出现，提高存活奖励
            survive_reward = 0.12 + 0.18 * step_norm

        # ===== 防磨蹭 + 位移引导 =====
        stuck_penalty = 0.0
        if len(self._pos_hist) >= STUCK_WINDOW + 1:
            # 惩罚：10步移动 < 5格
            if move_dist_10 < STUCK_DIST_THRESHOLD:
                stuck_penalty = -0.07

            # 引导：10步净位移越大，奖励越多
            x0, z0 = self._pos_hist[0]
            x1, z1 = self._pos_hist[-1]
            net_displacement = float(np.sqrt((x1 - x0) ** 2 + (z1 - z0) ** 2))
            stuck_penalty += net_displacement * 0.005  # 每前进1格+0.005

            # 检测来回走：净位移 < 总路程的一半
            if net_displacement < move_dist_10 * 0.5 and move_dist_10 > 10.0:
                stuck_penalty -= 0.1

        # ===== 防来回走（减弱）=====
        net_displacement = 0.0
        if len(self._pos_hist) >= STUCK_WINDOW:
            x0, z0 = self._pos_hist[0]
            x1, z1 = self._pos_hist[-1]
            net_displacement = np.sqrt((x1 - x0)**2 + (z1 - z0)**2)
            
            if net_displacement < 10.0 and move_dist_10 > 15.0:
                stuck_penalty -= 0.08   # ↓ 从-0.15→-0.05

                # ===== 死胡同（惩罚+逃生引导）=====
        dead_end_penalty = 0.0
        if trapped_norm > 0.85:
            # 重度死胡同：扣分 + 向开阔方向移动有奖励
            dead_end_penalty = -0.10
            # 引导：3步内最大通路深度越深，奖励越多
            dead_end_penalty += depth_norm * 0.03      # 最深通路引导
            dead_end_penalty += open_norm * 0.02       # 开阔区域引导
        elif trapped_norm > 0.65:
            # 中度死胡同：轻微惩罚
            dead_end_penalty = -0.02
            dead_end_penalty += depth_norm * 0.02
        else:
            # 开阔区域：给予安全红利
            dead_end_penalty = open_norm * 0.01

        # ===== 首次发现（削弱随机性）=====
        first_sight_bonus = min(first_sight_bonus, 0.12)  # ↓ 从0.5限制到0.15

        # ===== 最终 reward =====
        reward = [
            tre_event
            + buff_event
            + dist_shaping
            + flash_value
            + stuck_penalty
            + survive_reward
            + danger_penalty
            + dead_end_penalty
            + first_sight_bonus
            + treasure_approach
        ]

        self.last_min_monster_dist_norm = cur_min_dist_norm  
        self.last_tre_bucket_norm = tre_dist_bucket_norm
        if updated_bucket:
            self.last_bucket_score = bucket_score
        elif len(all_tre_bucket) == 0:
            self.last_bucket_score = 0.0
        # else: 保持上一帧（关键！）
        

                # ===== 调试打印（每局结束时打印汇总，每100步打印明细）=====
        if not hasattr(self, '_episode_reward_sum'):
            self._episode_reward_sum = 0.0
            self._episode_step = 0
            self._episode_tre_count = 0
            self._episode_last_treasure_score = 0.0

        self._episode_reward_sum += sum(reward)
        self._episode_step += 1

        # 检测吃宝箱
        if treasure_score > self._episode_last_treasure_score + 1e-6:
            self._episode_tre_count += 1
        self._episode_last_treasure_score = treasure_score

          # ===== 每局统计 =====
        if danger_penalty < 0:
            self.danger_steps += 1
        if stuck_penalty < 0:
            self.stuck_steps += 1
        if isinstance(last_action, (int, np.integer)) and 8 <= int(last_action) <= 15:
            self.flash_use_count += 1
            if flash_value > 0:
                self.flash_success_count += 1


        return feature, legal_action, reward
