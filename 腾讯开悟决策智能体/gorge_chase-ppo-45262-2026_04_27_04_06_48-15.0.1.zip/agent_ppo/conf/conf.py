#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Configuration for Gorge Chase PPO.
峡谷追猎 PPO 配置。
"""


class Config:

    # Map feature / 地图特征（局部视野 21×21）
    MAP_H = 21
    MAP_W = 21
    MAP_FLAT = MAP_H * MAP_W

    # Feature dimensions / 特征维度
    # 当前拆分：
    # - hero_self: 5
    # - monster_1 : 13
    # - monster_2 : 13
    # - buff_near : 4  (dist_norm + dir_onehot(8)改为2维的sin/cos + is_visible)
    # - trea_near : 44  (dist_norm + dir_onehot(8)改为2维的sin/cos + is_visible)
    # - anti_stuck: 1   (move_dist_10_norm)
    # - map_21x21 : 441 (flattened 0/1 passable)
    # - legal_act : 16
    # - progress  : 2
    FEATURES = [
        9,
        13,
        13,
        4,
        44,
        3,
        MAP_FLAT,
        16,
        2,
    ]
    FEATURE_SPLIT_SHAPE = FEATURES
    FEATURE_LEN = sum(FEATURE_SPLIT_SHAPE)
    DIM_OF_OBSERVATION = FEATURE_LEN

    # Scalar part dimension / 标量部分维度（除去 map_21x21）
    DIM_OF_SCALAR = DIM_OF_OBSERVATION - MAP_FLAT

    # Action space / 动作空间：16（8方向移动 + 8方向闪现）
    ACTION_NUM = 16

    # Value head / 价值头：单头生存奖励
    VALUE_NUM = 1

    # PPO hyperparameters / PPO 超参数
    GAMMA = 0.995
    LAMDA = 0.95
    INIT_LEARNING_RATE_START = 0.0003
    BETA_START = 0.01
    CLIP_PARAM = 0.2
    VF_COEF = 0.4
    GRAD_CLIP_RANGE = 0.5
