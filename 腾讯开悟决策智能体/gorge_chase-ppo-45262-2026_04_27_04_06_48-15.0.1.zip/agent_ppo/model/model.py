#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Neural network model for Gorge Chase PPO.
峡谷追猎 PPO 神经网络模型。

修复：新增 get_value() 方法，供 truncated bootstrap 使用。
"""

import torch
import torch.nn as nn
import numpy as np

from agent_ppo.conf.conf import Config


def make_fc_layer(in_features, out_features):
    """Create a linear layer with orthogonal initialization."""
    fc = nn.Linear(in_features, out_features)
    nn.init.orthogonal_(fc.weight.data)
    nn.init.zeros_(fc.bias.data)
    return fc


class Model(nn.Module):
    """Single MLP backbone + Actor/Critic dual heads."""

    def __init__(self, device=None):
        super().__init__()
        self.model_name = "gorge_chase_lite"
        self.device = device

        scalar_dim = Config.DIM_OF_SCALAR
        map_h, map_w = Config.MAP_H, Config.MAP_W
        map_flat = Config.MAP_FLAT

        hidden_dim = 128
        mid_dim = 64
        action_num = Config.ACTION_NUM
        value_num = Config.VALUE_NUM

        # Scalar backbone
        self.scalar_backbone = nn.Sequential(
            make_fc_layer(scalar_dim, hidden_dim),
            nn.ReLU(),
            make_fc_layer(hidden_dim, mid_dim),
            nn.ReLU(),
        )

        # Lightweight CNN for map (21x21)
        self.map_cnn = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(8, 16, kernel_size=3, padding=1),
            nn.ReLU(),
        )
        self.map_head = nn.Sequential(
            nn.Flatten(),
            make_fc_layer(16 * map_h * map_w, 32),
            nn.ReLU(),
            make_fc_layer(32, 32),
            nn.ReLU(),
        )

        # Fusion
        self.fusion = nn.Sequential(
            make_fc_layer(mid_dim + 32, mid_dim),
            nn.ReLU(),
        )

        # Actor head
        self.actor_head = make_fc_layer(mid_dim, action_num)

        # Critic head
        self.critic_head = make_fc_layer(mid_dim, value_num)

    def forward(self, obs, inference=False):
        scalar = obs[:, : Config.DIM_OF_SCALAR]
        map_flat = obs[:, Config.DIM_OF_SCALAR : Config.DIM_OF_SCALAR + Config.MAP_FLAT]

        scalar_hidden = self.scalar_backbone(scalar)
        map_tensor = map_flat.view(-1, 1, Config.MAP_H, Config.MAP_W)
        map_hidden = self.map_head(self.map_cnn(map_tensor))

        hidden = self.fusion(torch.cat([scalar_hidden, map_hidden], dim=1))
        logits = self.actor_head(hidden)
        value = self.critic_head(hidden)
        return logits, value

    def get_value(self, obs_feature):
        """
        【新增】用于 truncated bootstrap：给定单帧特征，返回 Critic 估计的 V(s)。
        obs_feature: list or np.ndarray, shape (FEATURE_LEN,)
        returns: np.ndarray shape (1,)
        """
        self.eval()
        with torch.no_grad():
            obs_tensor = torch.tensor(
                np.array([obs_feature], dtype=np.float32),
                dtype=torch.float32,
                device=self.device,
            )
            _, value = self.forward(obs_tensor, inference=True)
        return value.cpu().numpy().flatten()[:1]

    def set_train_mode(self):
        self.train()

    def set_eval_mode(self):
        self.eval()